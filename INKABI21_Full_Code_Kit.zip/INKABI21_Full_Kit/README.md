# INKABI.21 Full Starter Kit

## Included
- `index.html`: existing INKABI.21 interface with screenshot-to-backend workflow and additional correlated-market quote requests.
- `server.js`: protected backend endpoint that sends screenshots and current supplied context to a vision-capable OpenAI model.
- `package.json`: Node backend dependencies.
- `.env.example`: environment variable template.

## Important limits
- The HTML preserves the existing biquote.io feed dependency. Adding symbols to the request does not guarantee that provider supports every symbol. Unsupported symbols show unavailable; no prices are fabricated. Verify provider terms, supported instruments, timestamps and freshness.
- U.S. Treasury nominal/real yields are daily observations, not streaming intraday quotes.
- Screenshot interpretation requires a working backend, an OpenAI API key, provider access/billing and a compatible model. The key is kept on the backend, not in `index.html`.
- Public GitHub Pages alone cannot securely store private API keys or run the backend. Deploy `server.js` to a Node host that supports environment variables (e.g. Render/Railway or another trusted Node host). Free-tier availability/limits can change.
- This backend only analyses; it does not place orders or connect to MT5. Output is decision support, not a guaranteed signal.

## Deploy from a phone
1. Create a private backend project/repository if possible and upload `server.js`, `package.json`, and `.env.example` (do not commit a real `.env` file).
2. Deploy as a Node web service with build/install command `npm install` and start command `npm start`.
3. In the host dashboard, set `OPENAI_API_KEY` to your own secret key, `OPENAI_MODEL` to a model available to your account (default `gpt-4.1-mini`), and `ALLOWED_ORIGINS` to your exact GitHub Pages origin, e.g. `https://YOURNAME.github.io`. Do not use a wildcard origin in production.
4. After deployment, open `https://YOUR-BACKEND-DOMAIN/api/health`. It should return JSON with `ok: true` and `visionConfigured: true`. If false, check the server environment variable.
5. Publish `index.html` as the app's GitHub Pages `index.html`.
6. Open INKABI.21 → AI Intelligence. Paste the backend base URL (without `/api`), save it, test it, choose a screenshot, then tap ANALYZE GOLD.
7. Keep the key private. If it is exposed in HTML, a public repository, screenshots or chat, revoke it and create a new one.

## Before relying on market analysis
Check that each quote shows a valid timestamp and correct instrument. If the provider returns errors or unsupported symbols, use another provider or backend adapter; do not interpret blank fields as zero. Calendar/news search can be incomplete and needs source verification. Always verify price against your broker.
