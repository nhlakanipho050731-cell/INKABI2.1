import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "").split(",").map(s=>s.trim()).filter(Boolean);
app.disable("x-powered-by");
app.use(helmet({crossOriginResourcePolicy:{policy:"cross-origin"}}));
app.use(cors({origin(origin, cb){ if(!origin || allowedOrigins.length===0 || allowedOrigins.includes(origin)) return cb(null,true); return cb(new Error("Origin not allowed")); }}));
app.use(express.json({limit:"12mb"}));
app.use("/api/", rateLimit({windowMs:60_000,limit:12,standardHeaders:true,legacyHeaders:false}));
const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
app.get("/api/health", (_req,res)=>res.json({ok:true,visionConfigured:Boolean(client),model:MODEL,now:new Date().toISOString()}));
app.post("/api/analyze", async(req,res)=>{
 try {
  if(!client) return res.status(503).json({error:"Vision AI is not configured. Add OPENAI_API_KEY to the backend environment, never to the HTML file."});
  const {imageDataUrl,context}=req.body||{};
  if(typeof imageDataUrl!=="string" || !/^data:image\/(png|jpeg|webp);base64,/.test(imageDataUrl)) return res.status(400).json({error:"A PNG, JPEG or WebP data URL is required."});
  if(imageDataUrl.length>11_200_000) return res.status(413).json({error:"Image too large. Use an image under 8 MB."});
  const safeContext = JSON.stringify(context||{}).slice(0,24000);
  const prompt = `You are INKABI.21, a cautious XAU/USD chart and macro evidence assistant. Analyze the attached chart screenshot AND the supplied market context. Distinguish observations visible in the image from supplied live-feed values and from inference. Never invent price levels, timestamps, event actuals/forecasts, sources, or indicator values. If text is unreadable, say so. If the screenshot timeframe or symbol is not visible, mark unknown. Do not claim prices are live unless the context includes recent timestamped quotes; mention stale/missing data. Explain: (1) screenshot identification/readability; (2) trend/market structure and candlestick evidence; (3) visible support/demand and resistance/supply zones with approximate price only if legible; (4) liquidity sweep/breakout/rejection evidence only if actually visible; (5) macro alignment using XAUUSD, DXY, EURUSD, GBPUSD, USDJPY, silver, oil and US nominal/real yields when supplied; (6) latest relevant news/calendar catalysts and source limitations; (7) bullish and bearish scenarios, confirmation conditions, invalidation conditions; (8) risk gate. Do not provide a guaranteed prediction or instruct an automatic trade. Use WAIT if evidence conflicts or key data is missing. Use NO-GO if screenshot is unreadable, essential live quote data is missing/stale, or critical risk checks are unavailable. No execution or broker connection exists. Return plain text with concise headings and confidence expressed as low/moderate/high plus why. Context JSON: ${safeContext}`;
  const response = await client.responses.create({model:MODEL,input:[{role:"user",content:[{type:"input_text",text:prompt},{type:"input_image",image_url:imageDataUrl,detail:"high"}]}],max_output_tokens:1600});
  const analysis = (response.output_text||"").trim();
  if(!analysis) return res.status(502).json({error:"The AI provider returned an empty analysis."});
  res.json({ok:true,analysis,model:MODEL,analyzedAt:new Date().toISOString()});
 } catch(e) {
  console.error("/api/analyze failed:",e?.status||"",e?.message||"unknown");
  res.status(502).json({error:"AI analysis request failed. Check backend logs, provider billing/access, model availability and image format."});
 }
});
app.get("/",(_req,res)=>res.type("text").send("INKABI.21 AI backend is running. Use /api/health."));
app.listen(PORT,()=>console.log(`INKABI.21 backend listening on ${PORT}`));
